const catchAsync = require('../utils/catchAsync');
const AppError = require('../utils/appError');
const Request = require('../models/requestModel');
const Institute = require('../models/InstituteModel');
const Shop = require('../models/shopModel');
const User = require('../models/userModel');

// Create a new request
// Create a new request (for institutes)
exports.createRequest = catchAsync(async (req, res, next) => {
    // 1) Check if user is an institute
    if (req.user.role !== 'institute') {
        return next(new AppError('Only institutes can create requests', 403));
    }

    // 2) Find institute associated with the user
    const institute = await Institute.findOne({ user: req.user.id });
    if (!institute) {
        return next(new AppError('No institute found for this user', 404));
    }

    // 3) Create request with institute reference
    const { items, category, priority, comments } = req.body;
    
    const newRequest = await Request.create({
        institute: institute._id,  // Use the found institute's ID
        items,
        category,
        priority,
        comments
    });

    // 4) Populate institute details in response
    await newRequest.populate('institute');

    res.status(201).json({
        status: 'success',
        data: {
            request: newRequest
        }
    });
});

// Get all requests
exports.getAllRequests = catchAsync(async (req, res, next) => {
    let filter = {};

    switch (req.user.role) {
        case 'institute':
            const institute = await Institute.findOne({ user: req.user.id });
            filter.institute = institute._id;
            break;
        case 'shopkeeper':
            const shop = await Shop.findOne({ user: req.user.id });
            filter['fulfillmentDetails.shops'] = shop._id;
            break;
        case 'donor':
            filter['fulfillmentDetails.donors'] = req.user.id;
            break;
        case 'admin':
            break; // No filter
        default:
            return next(new AppError('Invalid user role', 400));
    }

    const requests = await Request.find(filter)
        .populate('institute')
        .populate('fulfillmentDetails.shops');

    res.status(200).json({
        status: 'success',
        results: requests.length,
        data: { requests }
    });
});

// Get a single request
exports.getRequest = catchAsync(async (req, res, next) => {
    const request = await Request.findById(req.params.id)
        .populate('institute')
        .populate('fulfillmentDetails.shops');

    if (!request) return next(new AppError('Request not found', 404));

    let hasAccess = false;
    switch (req.user.role) {
        case 'admin':
            hasAccess = true;
            break;
        case 'institute':
            hasAccess = request.institute.equals(req.user.id);
            break;
        case 'shopkeeper':
            const shop = await Shop.findOne({ user: req.user.id });
            hasAccess = request.fulfillmentDetails.shops.some(s => s.equals(shop._id));
            break;
        case 'donor':
            hasAccess = request.fulfillmentDetails.donors.some(d => d.equals(req.user.id));
            break;
    }

    if (!hasAccess) return next(new AppError('Access denied', 403));

    res.status(200).json({ status: 'success', data: { request } });
  });