const mongoose = require('mongoose');

const requestSchema = new mongoose.Schema({
    institute: { type: mongoose.Schema.Types.ObjectId, ref: 'Institute', required: true },
    items: [{
        name: { type: String, required: true },
        quantity: { type: Number, required: true },
        unit: { type: String, required: true }
    }],
    status: { type: String, enum: ['pending', 'fulfilled', 'partially fulfilled'], default: 'pending' },
    createdAt: { type: Date, default: Date.now },
    fulfillmentDetails: {
        shops: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Shop' }],
        donors: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }]
    },
    priority: { type: String, enum: ['low', 'medium', 'high'], default: 'medium' },
    comments: { type: String },
    category: {
        type: String,
        enum: ['education', 'health', 'food', 'medical emergencies'],
        required: [true, 'Category is required']
    },
});

module.exports = mongoose.model('Request', requestSchema);